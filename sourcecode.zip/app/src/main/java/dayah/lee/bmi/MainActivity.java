package dayah.lee.bmi;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private LinearLayout lyResult;
    private EditText etWeight, etHeight;
    private TextView tvResult, tvDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        etWeight = findViewById(R.id.etWeight);
        etHeight = findViewById(R.id.etHeight);
        tvResult = findViewById(R.id.tvResult);
        tvDescription = findViewById(R.id.tvDescription);
        lyResult = findViewById(R.id.lyResult);

        etWeight.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_NEXT) {
                    etHeight.requestFocus();
                    return true;
                }
                return false;
            }
        });

        etHeight.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    calculate();
                    return true;
                }
                return false;
            }
        });
    }

    public void resultBmi(View view) {
        calculate();
    }

    private void calculate(){
        if(etWeight.getText().toString().length() != 0 && etHeight.getText().toString().length() != 0){
            hideKeyboard(this);
            tvResult.setText(String.valueOf(calculate(Double.parseDouble(etWeight.getText().toString()), Double.parseDouble(etHeight.getText().toString()))));
        } else{
            Toast.makeText(this, "Please fill in all field", Toast.LENGTH_SHORT).show();
        }
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private double calculate(double weight, double height){
        double tHeight = height * height;
        double result = Math.round((weight/tHeight) * 100.0) / 100.0;
        String description = "";
        lyResult.setVisibility(View.VISIBLE);

        if(result<=18.5){
            description = "Underweight";
            tvResult.setTextColor(getResources().getColor(R.color.cUnderweight));
            tvDescription.setTextColor(getResources().getColor(R.color.cUnderweight));
        } else if(result<=25){
            description = "Normal weight";
            tvResult.setTextColor(getResources().getColor(R.color.cNormalweight));
            tvDescription.setTextColor(getResources().getColor(R.color.cNormalweight));
        } else if(result<=30){
            description = "Overweight";
            tvResult.setTextColor(getResources().getColor(R.color.cOverweight));
            tvDescription.setTextColor(getResources().getColor(R.color.cOverweight));
        }else if(result>30){
            description = "Obese";
            tvResult.setTextColor(getResources().getColor(R.color.cObese));
            tvDescription.setTextColor(getResources().getColor(R.color.cObese));
        }
        tvDescription.setText(description);
        return result;
    }

}
